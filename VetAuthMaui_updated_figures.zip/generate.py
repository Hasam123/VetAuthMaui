from pathlib import Path
import html, math, re, csv, zipfile
from PIL import Image, ImageDraw, ImageFont
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import A4, landscape
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont

ROOT=Path(__file__).parent
FONT='C:/Windows/Fonts/times.ttf'
BOLD='C:/Windows/Fonts/timesbd.ttf'
pdfmetrics.registerFont(TTFont('Thesis',FONT))
names={1:'Блок-схема алгоритма авторизации пользователя',2:'Блок-схема алгоритма загрузки и фильтрации списка услуг',3:'Блок-схема алгоритма формирования свободных временных интервалов',4:'Блок-схема алгоритма создания заявки на приём',5:'Блок-схема алгоритма работы личного кабинета клиента',6:'Блок-схема алгоритма сохранения медицинской записи',7:'Блок-схема алгоритма формирования статистики',8:'Архитектура программного продукта',9:'Структура мобильного приложения',10:'Взаимодействие компонентов системы',11:'ER-диаграмма базы данных',14:'Логическая структура программного продукта',15:'UML-диаграмма последовательности процесса записи на приём',16:'Логическая структура мобильного приложения',17:'Логическая структура серверной части',18:'UML-диаграмма вариантов использования системы'}
class D:
 def __init__(self,n,w=1200,h=1550):
  self.n=n; self.w=w; self.h=h; self.im=Image.new('RGB',(w*2,h*2),'white');self.dr=ImageDraw.Draw(self.im);self.s=[f'<svg xmlns="http://www.w3.org/2000/svg" width="{w}" height="{h}" viewBox="0 0 {w} {h}"><rect width="100%" height="100%" fill="white"/>'];self.boxes={}
 def line(self,pts,dash=False,arrow=False,width=1.8):
  self.dr.line([(int(x*2),int(y*2)) for x,y in pts],fill='black',width=max(2,int(width*2)))
  attr=' stroke-dasharray="8 6"' if dash else ''
  self.s.append('<polyline points="'+' '.join(f'{x},{y}' for x,y in pts)+f'" fill="none" stroke="black" stroke-width="{width}"{attr}/>')
  if arrow:
   x,y=pts[-1];a=math.atan2(y-pts[-2][1],x-pts[-2][0]);q=[(x,y),(x-12*math.cos(a-.42),y-12*math.sin(a-.42)),(x-12*math.cos(a+.42),y-12*math.sin(a+.42))];self.poly(q,fill='black')
 def poly(self,p,fill='white'):
  self.dr.polygon([(int(x*2),int(y*2)) for x,y in p],fill=fill);self.dr.line([(int(x*2),int(y*2)) for x,y in p+[p[0]]],fill='black',width=3)
  self.s.append('<polygon points="'+' '.join(f'{x},{y}' for x,y in p)+f'" fill="{fill}" stroke="black" stroke-width="1.5"/>')
 def text(self,x,y,t,size=27,bold=False,maxw=None):
  font=ImageFont.truetype(BOLD if bold else FONT,size*2); lines=[]
  for p in str(t).split('\n'):
   if maxw:
    line=''
    for word in p.split():
     q=(line+' '+word).strip()
     if line and self.dr.textlength(q,font=font)>maxw*2:lines.append(line);line=word
     else:line=q
    lines.append(line)
   else:lines.append(p)
  top=y-(len(lines)-1)*size*.61
  for i,l in enumerate(lines):
   yy=top+i*size*1.22;self.dr.text((x*2,yy*2),l,font=font,fill='black',anchor='mm')
   self.s.append(f'<text x="{x}" y="{yy}" text-anchor="middle" dominant-baseline="central" font-family="Times New Roman,serif" font-size="{size}"'+(' font-weight="bold"' if bold else '')+'>'+html.escape(l)+'</text>')
 def box(self,key,x,y,w,h,t,shape='rect',size=27):
  self.boxes[key]=(x,y,w,h)
  if shape=='diamond':self.poly([(x+w/2,y),(x+w,y+h/2),(x+w/2,y+h),(x,y+h/2)])
  elif shape=='io':self.poly([(x+24,y),(x+w,y),(x+w-24,y+h),(x,y+h)])
  elif shape in ('round','ellipse'):
   if shape=='ellipse':self.dr.ellipse((x*2,y*2,(x+w)*2,(y+h)*2),fill='white',outline='black',width=3);self.s.append(f'<ellipse cx="{x+w/2}" cy="{y+h/2}" rx="{w/2}" ry="{h/2}" fill="white" stroke="black" stroke-width="1.5"/>')
   else:self.dr.rounded_rectangle((x*2,y*2,(x+w)*2,(y+h)*2),radius=40,fill='white',outline='black',width=3);self.s.append(f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="20" fill="white" stroke="black" stroke-width="1.5"/>')
  else:self.poly([(x,y),(x+w,y),(x+w,y+h),(x,y+h)])
  self.text(x+w/2,y+h/2,t,size,maxw=w*(.66 if shape=='diamond' else .91))
 def pos(self,k,side):
  x,y,w,h=self.boxes[k];return {'t':(x+w/2,y),'b':(x+w/2,y+h),'l':(x,y+h/2),'r':(x+w,y+h/2)}[side]
 def link(self,a,b,sa='b',sb='t',via=None,label=None,dash=False):
  p=[self.pos(a,sa)]+(via or [])+[self.pos(b,sb)];self.line(p,dash,True)
  if label:self.text((p[0][0]+p[1][0])/2+27,(p[0][1]+p[1][1])/2-12,label,23)
 def save(self):
  stem=f'Figure_2_{self.n:02d}';self.s.append('</svg>');(ROOT/(stem+'.svg')).write_text('\n'.join(self.s),encoding='utf-8');self.im.save(ROOT/(stem+'.png'),dpi=(300,300));return self

def flow(n,steps,fail='Сообщение об ошибке',note=None):
 # Each decision has a downward Yes branch and a rightward No branch.
 heights=[130 if shape=='diamond' else 100 for _,shape in steps]
 h=100+sum(heights)+65*(len(steps)-1)+100
 d=D(n,1200,h);y=45;prev=None;dec=[]
 for i,((t,shape),hh) in enumerate(zip(steps,heights)):
  w=640 if shape!='round' else 350;x=380-w/2;d.box(str(i),x,y,w,hh,t,shape,26)
  if prev is not None:d.link(prev,str(i),label='Да' if steps[i-1][1]=='diamond' else None)
  if shape=='diamond':dec.append(str(i))
  prev=str(i);y+=hh+65
 if dec:
  ey=d.pos(dec[len(dec)//2],'r')[1];d.box('err',880,ey-65,285,130,fail,'io',24)
  for key in dec:
   p=d.pos(key,'r');d.link(key,'err','r','t',via=[(820,p[1]),(820,ey-100),(1022,ey-100)],label='Нет')
  d.link('err',prev,'b','r',via=[(1022,h-105)],label=None)
 if note:d.text(610,h-25,note,21)
 return d.save()

flow(1,[('Начало','round'),('Выбор входа: клиент / ветеринар','rect'),('Телефон / логин и пароль','io'),('Поля заполнены?','diamond'),('POST: clients/login.php\nили admin/login.php','rect'),('Учётная запись найдена,\nпароль подтверждён?','diamond'),('Сохранить данные пользователя в State;\nоткрыть клиентское меню / меню ветеринара','rect'),('Конец','round')])
flow(2,[('Начало','round'),('GET services/list.php','rect'),('Получен корректный ответ?','diamond'),('Сохранить список услуг в приложении','rect'),('Ввести название / выбрать категорию','io'),('Отфильтровать локальный список','rect'),('Показать подходящие услуги и цены','io'),('Конец','round')])

# Availability: an inactive veterinarian has no selectable slots, rather than an API failure.
d=D(3,1200,1510)
for k,x,y,w,h,t,s in [('a',360,35,400,80,'Начало','round'),('b',230,165,660,100,'Получить doctor_id; проверить врача','rect'),('c',310,320,500,130,'Врач существует?','diamond'),('d',200,505,720,115,'Сформировать интервалы на 5 дней\n08:00–18:00, шаг 30 минут','rect'),('e',235,680,650,175,'Врач активен, время в будущем\nи интервал свободен?','diamond'),('f',80,950,450,105,'Отметить интервал доступным','rect'),('g',690,950,450,105,'Отметить интервал недоступным','rect'),('h',245,1160,650,105,'Повторить проверку для всех интервалов;\nвернуть JSON и серверное время','rect'),('i',370,1350,400,80,'Конец','round')]:d.box(k,x,y,w,h,t,s,26)
for a,b in [('a','b'),('b','c'),('c','d'),('d','e'),('h','i')]:d.link(a,b,label='Да' if a=='c' else None)
d.box('err',940,320,230,130,'Ошибка выбора врача','io',24);d.link('c','err','r','l',label='Нет');d.link('err','i','b','r',via=[(1170,450),(1170,1390)])
d.link('e','f','l','t',via=[(305,767),(305,910)],label='Да');d.link('e','g','r','t',via=[(915,767),(915,910)],label='Нет');d.link('f','h','b','t',via=[(305,1110),(570,1110)]);d.link('g','h','b','t',via=[(915,1110),(570,1110)]);d.text(600,1480,'Часовой пояс Europe/Chisinau; занятость учитывается отдельно для врача',23);d.save()

flow(4,[('Начало','round'),('Выбрать питомца, услугу, ветеринара, дату и время','io'),('Обязательные данные заполнены?','diamond'),('POST appointments/create.php','rect'),('Врач активен; услуга и питомец\nдоступны; время свободно и не прошло?','diamond'),('Начать транзакцию; определить питомца;\nповторно проверить время перед INSERT','rect'),('Сохранение успешно?','diamond'),("Создать заявку со статусом new; COMMIT",'rect'),('Конец','round')],fail='Отказ; при начатой транзакции — ROLLBACK')
flow(5,[('Начало','round'),('Загрузить профиль текущего клиента\nGET clients/profile.php?phone=…','rect'),('Данные получены?','diamond'),('Показать ФИО, телефон и адрес\nбез редактирования адреса','io'),('Показать записи: ветеринар, питомец,\nуслуга, время, статус и медкарта','io'),('При отмене: POST appointments/cancel.php','rect'),('Запись принадлежит клиенту\nи имеет статус new / accepted?','diamond'),('Отменить запись; обновить список','rect'),('Конец','round')],fail='Сообщение об ошибке / отказ в отмене')
flow(6,[('Начало','round'),('Заполнить карту; выбрать первичный / повторный приём;\nпри повторном — просмотреть прошлое посещение','io'),('Жалобы, хотя бы один диагноз\nи лечение / процедуры заполнены?','diamond'),('POST update_medical_record.php; BEGIN;\nзаблокировать строку приёма','rect'),('Приём существует и не отменён;\nдата и первичный приём корректны?','diamond'),('INSERT / UPDATE medical_records;\nсохранить perv_priem_id; установить done','rect'),('При первом переходе в done триггер\nкопирует данные в service_history','rect'),('Все операции выполнены?','diamond'),('COMMIT; показать результат','rect'),('Конец','round')],fail='Отказ; ROLLBACK начатой транзакции',note='Повторное сохранение карты не изменяет ранее созданную строку истории')
flow(7,[('Начало','round'),('GET admin/stats.php','rect'),('Посчитать заявки по статусам\nnew / accepted / done / cancelled','rect'),('Посчитать общее число заявок и услуг','rect'),('Вернуть статистику в JSON','io'),('Отобразить показатели в меню ветеринара','io'),('Конец','round')],note='Текущий stats.php считает общие показатели системы')

# Architecture, same components, different perspectives.
d=D(8,1200,940)
d.box('u',380,45,440,90,'Клиент / ветеринар','round');d.box('m',180,220,840,150,'Уровень представления\n.NET MAUI: XAML, C#, страницы и модели');d.box('p',180,485,840,150,'Уровень обработки\nApache + PHP API: проверки и транзакции');d.box('db',180,750,840,145,'Уровень хранения\nБаза vet_clinic: таблицы, ограничения и триггеры')
d.link('u','m');d.link('m','p',label='HTTP / JSON');d.link('p','db',label='SQL / mysqli');d.save()

d=D(9,1400,1140)
d.box('a',470,40,460,90,'Мобильное приложение','round');d.box('c',50,240,600,90,'Клиентская часть');d.box('v',750,240,600,90,'Часть ветеринара');d.link('a','c',via=[(700,180),(350,180)]);d.link('a','v',via=[(700,180),(1050,180)])
for i,(c,v) in enumerate([('Регистрация и вход','Вход по логину и паролю'),('Питомцы; услуги и цены','Свои записи и расписание'),('Запись к выбранному ветеринару','Медкарта; предыдущие посещения'),('Личный кабинет; отмена записи','Услуги; общая статистика')]):
 y=400+i*150;d.box('c'+str(i),60,y,580,100,c);d.box('v'+str(i),760,y,580,100,v)
 d.link('c','c'+str(i),'l','l',via=[(25,285),(25,y+50)])
 d.link('v','v'+str(i),'l','l',via=[(715,285),(715,y+50)])
d.text(700,1080,'Общие страницы: «О приложении», «Контакты»; навигация AppShell',27);d.save()

d=D(10,1300,1030)
for k,x,y,w,h,t in [('u',440,40,420,85,'Пользователь'),('m',320,245,660,130,'Мобильное приложение\nформирование запроса / показ ответа'),('p',320,535,660,130,'PHP API\nпроверки, запросы и JSON'),('b',320,845,660,130,'vet_clinic\nтаблицы и триггеры')]:d.box(k,x,y,w,h,t,'round' if k=='u' else 'rect')
for a,b,la,lb in [('u','m','Действие','Результат'),('m','p','HTTP-запрос JSON','JSON-ответ'),('p','b','SQL / транзакция','Результат SQL')]:
 ax,ay,aw,ah=d.boxes[a];bx,by,bw,bh=d.boxes[b];d.line([(ax+aw*.3,ay+ah),(bx+bw*.3,by)],arrow=True);d.line([(bx+bw*.7,by),(ax+aw*.7,ay+ah)],arrow=True);d.text(260,(ay+ah+by)/2,la,24,maxw=280);d.text(1050,(ay+ah+by)/2,lb,24,maxw=260)
d.save()

# ER model is generated from the actual database field list; history has NO FK edges.
schema={}
for row in csv.DictReader((ROOT/'schema.tsv').read_text(encoding='utf-8-sig').splitlines(),delimiter='\t'):schema.setdefault(row['TABLE_NAME'],[]).append((row['COLUMN_NAME'],row['COLUMN_TYPE']))
d=D(11,1860,1590)
coords={'vladelci':(35,40,490),'pets':(35,465,490),'admins':(650,40,510),'services':(35,1070,490),'zapic_na_priem':(650,445,510),'medical_records':(650,1040,510),'service_history':(1295,40,530)}
fk={('pets','client_id'),('zapic_na_priem','pet_id'),('zapic_na_priem','service_id'),('zapic_na_priem','doctor_id'),('zapic_na_priem','perv_priem_id'),('medical_records','id')}
for table,cols in schema.items():
 x,y,w=coords[table];hh=65+len(cols)*34;d.box(table,x,y,w,hh,'');d.line([(x,y+55),(x+w,y+55)]);d.text(x+w/2,y+27,table,28,True)
 for j,(field,typ) in enumerate(cols):
  suffix=' [PK]' if field=='id' else ''
  if (table,field) in fk:suffix+=' [FK]'
  d.text(x+w/2,y+77+j*34,f'{field}{suffix} : {typ}',22)
# Relationship routes avoid table bodies. Labels explicitly identify optionality.
d.link('vladelci','pets',label='1 : N');d.link('admins','zapic_na_priem',label='1 : 0..N')
d.link('pets','zapic_na_priem','r','l',via=[(590,coords['pets'][1]+(65+len(schema['pets'])*34)/2),(590,700)],label='1 : N')
d.link('services','zapic_na_priem','r','l',via=[(565,coords['services'][1]+(65+len(schema['services'])*34)/2),(565,880)],label='1 : N')
d.link('zapic_na_priem','medical_records',label='1 : 0..1')
x,y,w,h=d.boxes['zapic_na_priem'];d.line([(x+w,y+100),(1220,y+100),(1220,y+220),(x+w,y+220)],arrow=True);d.text(1230,y+325,'perv_priem_id\nпервичный: 1\nповторные:\n0..N',19,maxw=115)
d.text(1560,1100,'service_history — 27 полей\nКопии значений при завершении приёма.\nВнешних ключей нет.',25,maxw=525)
d.text(1560,1280,'PK — первичный ключ; FK — внешний ключ.\nmedical_records.id берётся из id приёма.\nclient_id и pet_id в истории — копии чисел.',23,maxw=520)
d.text(930,1540,'Стрелки показывают связи по внешним ключам; service_history хранится независимо',25);d.save()

d=D(14,1300,1150)
for k,y,t in [('u',45,'Пользователь: действие на странице'),('m',255,'Приложение: данные формы → HTTP-запрос'),('p',465,'PHP API: проверка → SQL → обработка результата'),('b',675,'База: таблицы, ограничения, транзакции, триггеры'),('r',885,'JSON-ответ → обновление интерфейса')]:d.box(k,230,y,840,125,t)
for a,b in [('u','m'),('m','p'),('p','b'),('b','r')]:d.link(a,b)
d.text(650,1090,'Мобильное приложение не подключается к базе напрямую',26);d.save()

# UML sequence with explicit success / rejection alternatives.
d=D(15,1500,1520);xs=[160,550,950,1340]
for i,(x,t) in enumerate(zip(xs,['Клиент','Приложение','PHP API','База данных'])):d.box('p'+str(i),x-120,35,240,85,t);d.line([(x,120),(x,1440)],dash=True)
def msg(a,b,y,t,ret=False):
 d.line([(xs[a],y),(xs[b],y)],dash=ret,arrow=True);d.text((xs[a]+xs[b])/2,y-27,t,23,maxw=abs(xs[a]-xs[b])-10)
msg(0,1,205,'Выбор ветеринара')
msg(1,2,300,'GET free_slots.php?doctor_id=…')
msg(2,3,395,'Активность врача и занятость')
msg(3,2,475,'Данные расписания',True)
msg(2,1,555,'Интервалы и серверное время',True)
msg(0,1,650,'Выбор питомца, услуги и времени')
msg(1,2,745,'POST appointments/create.php')
msg(2,3,840,'Проверки; BEGIN; повторная проверка времени')
d.line([(400,900),(1470,900),(1470,1370),(400,1370),(400,900)]);d.text(460,925,'alt',22,True)
msg(2,3,1000,'[Данные допустимы] INSERT; COMMIT')
msg(3,2,1070,'Новая заявка',True);msg(2,1,1140,'success = true',True)
d.line([(400,1180),(1470,1180)],dash=True);msg(2,1,1260,'[Ошибка] success = false; при необходимости ROLLBACK',True)
msg(1,0,1430,'Подтверждение / сообщение об ошибке',True);d.save()

d=D(16,1400,1300)
for k,x,y,w,h,t in [('app',470,35,460,90,'App → AppShell'),('client',45,270,610,130,'Страницы клиента\nMainPage, ClientPage, PetsPage, RecordPage'),('vet',745,270,610,130,'Страницы ветеринара\nAdminLogin, RequestPage, MedicalRecordPage'),('models',45,570,610,120,'Модели JSON\nClient, Pet, Doctor, Appointment, PrimaryVisit'),('records',745,570,610,120,'DoctorRecords\nзагрузка записей текущего ветеринара'),('state',45,845,610,120,'State\nданные текущего клиента / ветеринара'),('api',745,845,610,120,'Api.BaseUrl + HttpClient\nадрес сервера; GET / POST'),('server',470,1130,460,100,'PHP API')]:d.box(k,x,y,w,h,t)
d.link('app','client',via=[(700,195),(350,195)]);d.link('app','vet',via=[(700,195),(1050,195)]);d.link('client','models');d.link('vet','records');d.link('models','state');d.link('records','api');d.link('api','server',via=[(1050,1050),(700,1050)]);d.link('models','api','r','l',via=[(700,630),(700,905)],label='JSON');d.save()

d=D(17,1500,1330)
d.box('root',510,35,480,90,'C:\\xampp\\htdocs\\veterenar');d.box('api',540,205,420,85,'api/ — HTTP-маршруты');d.link('root','api')
groups=[('clients/','login, register, profile'),('pets/','list, create, update, delete'),('appointments/','list, create, cancel, delete; previous;\nupdate_status, update_admin_comment,\nupdate_medical_record'),('doctors/ + schedule/','doctors/list; schedule/free_slots'),('services/ + admin/','services: list, create, update, delete;\nadmin: login, stats')]
for i,(head,body) in enumerate(groups):
 y=355+i*150;d.box('g'+str(i),65,y,890,120,head+'\n'+body,size=25)
 d.link('api','g'+str(i),'r','r',via=[(1000,247),(1000,y+60)])
d.box('helpers',1080,450,380,220,'includes/\ndoctor_booking.php\njournal.php\nclinic_time.php',size=25);d.box('db',1080,820,380,115,'db.php\nподключение mysqli');d.box('mysql',1080,1090,380,100,'База vet_clinic');d.link('helpers','db');d.link('db','mysql');d.text(760,1270,'Общие файлы подключаются через require / require_once; маршруты возвращают JSON',24);d.save()

# UML use cases, two actors, each connected to the appropriate use cases.
d=D(18,1600,1500)
d.line([(330,45),(1270,45),(1270,1455),(330,1455),(330,45)]);d.text(800,80,'Мобильная система ветеринарного кабинета',30,True)
def actor(x,y,t):
 d.dr.ellipse(((x-20)*2,(y-70)*2,(x+20)*2,(y-30)*2),outline='black',width=3);d.s.append(f'<circle cx="{x}" cy="{y-50}" r="20" fill="white" stroke="black" stroke-width="1.5"/>');d.line([(x,y-30),(x,y+35)]);d.line([(x-45,y),(x+45,y)]);d.line([(x,y+35),(x-35,y+85)]);d.line([(x,y+35),(x+35,y+85)]);d.text(x,y+125,t,29)
actor(130,690,'Клиент');actor(1470,690,'Ветеринар')
client=['Регистрация и вход','Управление питомцами','Просмотр услуг и цен','Запись к ветеринару','Личный кабинет и медкарты','Отмена активной записи']
vet=['Вход ветеринара','Просмотр своих приёмов','Просмотр расписания','Заполнение медкарты','Предыдущие посещения','Управление услугами','Общая статистика']
for i,t in enumerate(client):
 y=160+i*190;d.box('c'+str(i),385,y,370,105,t,'ellipse',25);d.line([(180,690),(385,y+52)])
for i,t in enumerate(vet):
 y=160+i*170;d.box('v'+str(i),845,y,370,105,t,'ellipse',25);d.line([(1420,690),(1215,y+52)])
d.save()

pdf=canvas.Canvas(str(ROOT/'VetAuthMaui_figures.pdf'))
for n,title in names.items():
 im=Image.open(ROOT/f'Figure_2_{n:02d}.png');iw,ih=im.size
 pw,ph=landscape(A4) if n in (11,15,17,18) else A4;pdf.setPageSize((pw,ph));pdf.setFont('Thesis',12)
 # Wrap long captions without clipping.
 words=f'Рисунок 2.{n} — {title}'.split();lines=[];line=''
 for word in words:
  q=(line+' '+word).strip()
  if pdfmetrics.stringWidth(q,'Thesis',12)>pw-60:lines.append(line);line=word
  else:line=q
 lines.append(line);cap=22+len(lines)*15;scale=min((pw-50)/iw,(ph-cap-25)/ih);w,h=iw*scale,ih*scale
 pdf.drawImage(str(ROOT/f'Figure_2_{n:02d}.png'),(pw-w)/2,cap+(ph-cap-25-h)/2,width=w,height=h)
 for i,l in enumerate(lines):pdf.drawCentredString(pw/2,cap-15-i*15,l)
 pdf.showPage()
pdf.save()
readme=['# Обновлённые рисунки VetAuthMaui','', 'PNG: 300 dpi, белый фон; SVG: редактируемые векторные изображения.','В PNG и SVG подписи не встроены: добавьте их средствами Word. В PDF подписи присутствуют.','', '| Файл | Подпись в дипломе |','|---|---|']
for n,title in names.items():readme.append(f'| Figure_2_{n:02d}.png / .svg | Рисунок 2.{n} — {title} |')
readme+=['','Рисунки 2.12 и 2.13 (макеты интерфейса) и скриншоты не заменяются.','Схема 2.11 построена по фактическим именам, типам и полям базы vet_clinic.','Правильное имя хранилища: service_history, без s после service. В таблице 2.1 новой версии диплома есть опечатка services_history.','service_history показана без внешних ключей. medical_records.id — PK и FK, не AUTO_INCREMENT.','В 2.7 общая статистика отражает фактический API; она не ограничена текущим врачом.','Фильтрация по врачу на схеме не означает наличия полноценной серверной авторизации.','После замены схем обновите связанные описания, подписи и перекрёстные ссылки.','Схемы построены по исходникам и структуре БД, проверенным 30.10.2026.']
(ROOT/'README.md').write_text('\n'.join(readme),encoding='utf-8')
with zipfile.ZipFile(ROOT.parent/'VetAuthMaui_updated_figures.zip','w',zipfile.ZIP_DEFLATED) as z:
 for f in ROOT.iterdir():
  if f.suffix in ('.png','.svg','.pdf','.md','.py','.tsv'):z.write(f,f.name)
print('Generated',len(names),'PNG + SVG diagrams, PDF and ZIP')
