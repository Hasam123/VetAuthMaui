from pathlib import Path
import csv, math
root=Path(__file__).parent
source=(root/'generate.py').read_text(encoding='utf-8')
exec(compile(source.split('flow(1,')[0],str(root/'generate.py'),'exec'))
schema={}
for row in csv.DictReader((root/'er_current_schema.tsv').read_text(encoding='utf-8-sig').splitlines(),delimiter='\t'):
 schema.setdefault(row['TABLE_NAME'],[]).append(row)
d=D(11,2150,1850)
coords={'vladelci':(45,70,520),'pets':(45,540,520),'services':(45,1140,520),
 'admins':(795,70,550),'zapic_na_priem':(795,535,550),'medical_records':(795,1150,550),'service_history':(1535,70,570)}
fks={('pets','client_id'),('zapic_na_priem','pet_id'),('zapic_na_priem','service_id'),('zapic_na_priem','doctor_id'),('zapic_na_priem','perv_priem_id'),('medical_records','id')}
for table,rows in schema.items():
 x,y,w=coords[table];h=62+len(rows)*33
 d.box(table,x,y,w,h,'');d.line([(x,y+56),(x+w,y+56)]);d.text(x+w/2,y+27,table,29,True)
 for i,r in enumerate(rows):
  field=r['COLUMN_NAME'];typ=r['COLUMN_TYPE'].upper();typ=__import__('re').sub(r'INT\(11\)','INT',typ)
  keys=('PK ' if field=='id' else '')+('FK ' if (table,field) in fks else '')
  d.text(x+w/2,y+79+i*33,f'{keys}{field} : {typ}',22)

def symbol(p,q,kind):
 # Mark close to table p, along the first segment pointing toward the relationship.
 dx,dy=q[0]-p[0],q[1]-p[1];norm=math.hypot(dx,dy);u=(dx/norm,dy/norm);v=(-u[1],u[0])
 def at(t,off=0):return(p[0]+u[0]*t+v[0]*off,p[1]+u[1]*t+v[1]*off)
 def bar(t):d.line([at(t,-13),at(t,13)],width=2)
 def circle(t):
  c=at(t);r=7;pts=[(c[0]+r*math.cos(a*math.pi/16),c[1]+r*math.sin(a*math.pi/16)) for a in range(33)];d.line(pts,width=2)
 if kind=='one':bar(12);bar(25)
 elif kind=='optional':bar(12);circle(30)
 elif kind=='many':
  d.line([at(4,-15),at(25),at(4,15)],width=2);d.line([at(4),at(25)],width=2);circle(43)

def relation(a,b,sa,sb,via=None,ka='one',kb='many',label=None,labelpos=None,start=None,end=None):
 pts=[start or d.pos(a,sa)]+(via or [])+[end or d.pos(b,sb)];d.line(pts,width=2)
 symbol(pts[0],pts[1],ka);symbol(pts[-1],pts[-2],kb)
 if label and labelpos:d.text(*labelpos,label,24)

relation('vladelci','pets','b','t',label='владеет',labelpos=(420,445))
relation('admins','zapic_na_priem','b','t',ka='optional',label='ведёт приём',labelpos=(1240,420))
relation('pets','zapic_na_priem','r','l',via=[(675,703),(675,650)],end=(795,650),label='посещает',labelpos=(680,600))
relation('services','zapic_na_priem','r','l',via=[(640,1254),(640,730)],end=(795,730),label='заказана',labelpos=(675,1090))
relation('zapic_na_priem','medical_records','b','t',kb='optional',label='имеет медкарту',labelpos=(1220,1080))
relation('zapic_na_priem','zapic_na_priem','r','r',start=(1345,614),end=(1345,977),via=[(1445,614),(1445,977)],ka='optional',kb='many')
d.text(1440,1085,'perv_priem_id\nпервичный /\nповторный',21,maxw=150)
d.text(1820,1080,'service_history — независимое хранилище.\n27 полей; значения копируются\nтриггерами при завершении приёма.\nВнешних ключей нет.',25,maxw=555)
d.text(1815,1315,'medical_records.id — PK и FK;\nзначение совпадает с id приёма.\nclient_id и pet_id в истории —\nкопии чисел, а не внешние ключи.',24,maxw=550)
# Explicit symbolic legend.
for x,kind,t in [(100,'one','ровно один'),(700,'optional','ноль или один'),(1360,'many','ноль или много')]:
 p=(x,1730);q=(x+100,1730);d.line([p,q]);symbol(p,q,kind);d.text(x+275,1730,t,26)
d.text(1075,1805,'PK — первичный ключ; FK — внешний ключ. Символы у концов линий задают кратность связей.',25)
d.s.append('</svg>')
(root/'VetAuthMaui_ER_crowfoot.svg').write_text('\n'.join(d.s),encoding='utf-8')
d.im.save(root/'VetAuthMaui_ER_crowfoot.png',dpi=(300,300))
print('ER diagram created: 7 tables, 27 history fields, crow-foot notation')
